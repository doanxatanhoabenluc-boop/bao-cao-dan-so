function formatSoHoBaoCao(row, fallback = '') {
    const ma = row?.ho_so ?? row?.so_ho ?? row?.ma_ho ?? fallback;
    const ghiChu = row?.ghi_chu_ma_ho ?? '';
    const esc = v => String(v ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    return `${esc(ma)}${ghiChu ? `<br><small>${esc(ghiChu)}</small>` : ''}`;
}
document.addEventListener("DOMContentLoaded", function () {
    fetchUserDataAndInit();
});

let currentUserGlobal = null;
let allDiaBanData = [];
let currentCommuneSettings = { ten_xa: '', ten_tinh: '', ten_tram_y_te: '' };

// Hàm hỗ trợ định dạng ngày từ YYYY-MM-DD sang DD/MM/YYYY
function formatDateVN(dateString) {
    if (!dateString) return "";
    let datePart = dateString.split(' ')[0];
    let parts = datePart.split('-');
    if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateString;
}

async function fetchUserDataAndInit() {
    try {
        const res = await fetch('/api/me');
        const user = await res.json();
        
        if (!user || !user.id) {
            window.location.href = "index.html";
            return;
        }

        currentUserGlobal = user;
        try {
            const communeRes = await fetch('/api/public/thong-tin-xa', { cache: 'no-store' });
            if (communeRes.ok) currentCommuneSettings = await communeRes.json();
        } catch (communeError) {
            console.error('Lỗi tải thông tin xã:', communeError);
        }
        document.getElementById("txtNoiNhanBaoCao").innerText = currentCommuneSettings.ten_tram_y_te || '';
        document.getElementById("txtXa").innerText = currentCommuneSettings.ten_xa || user.xa || '';
        document.getElementById("txtTinh").innerText = currentCommuneSettings.ten_tinh || user.tinh || '';
        document.getElementById("signCommune").innerText = currentCommuneSettings.ten_xa || user.xa || '';

        document.getElementById("lblReporterName").innerText = user.fullname || user.username;
        document.getElementById("signCtvName").innerText = user.fullname || user.username;
        document.getElementById("signAdminName").innerText = user.role === "admin" ? (user.fullname || user.username) : "..............................................";

        const filterApSelect = document.getElementById("filterAp");
        const filterDiaBanSelect = document.getElementById("filterDiaBan");

        await loadApDiaBanStructure();

        if (user.role === "cộng tác viên ấp" || (user.role !== "admin" && user.role !== "lãnh đạo" && user.diabanh)) {
            filterApSelect.innerHTML = `<option value="${user.ap}">${user.ap}</option>`;
            filterApSelect.disabled = true;

            filterDiaBanSelect.innerHTML = `<option value="${user.diabanh}">${user.diabanh}</option>`;
            filterDiaBanSelect.disabled = true;
            
            document.getElementById("txtDiaBan").innerText = user.diabanh || "Chưa phân địa bàn";
            document.getElementById("txtAp").innerText = user.ap || "Chưa phân ấp";
        } else {
            document.getElementById("txtDiaBan").innerText = "Toàn xã";
            document.getElementById("txtAp").innerText = "Toàn xã";
        }

        document.getElementById("txtXa").innerText = currentCommuneSettings.ten_xa || user.xa || '';
        document.getElementById("txtTinh").innerText = currentCommuneSettings.ten_tinh || user.tinh || '';

        loadReportData();

    } catch (err) {
        console.error("Lỗi khởi tạo báo cáo:", err);
    }
}

async function loadApDiaBanStructure() {
    try {
        const resAp = await fetch('/api/danh-sach-ap');
        const apData = await resAp.json();

        const filterApSelect = document.getElementById("filterAp");
        if (!filterApSelect.disabled && Array.isArray(apData)) {
            let options = `<option value="">Toàn xã (Tất cả các ấp)</option>`;
            apData.forEach(item => {
                let tenAp = item.ten_ap;
                options += `<option value="${tenAp}">${tenAp}</option>`;
            });
            filterApSelect.innerHTML = options;
        }

        const resUsers = await fetch('/api/admin/users');
        const usersData = await resUsers.json();
        
        if (Array.isArray(usersData)) {
            allDiaBanData = usersData; 
        }
    } catch (err) {
        console.error("Lỗi tải danh mục ấp và địa bàn:", err);
    }
}

function onApChange() {
    const selectedAp = document.getElementById("filterAp").value;
    const filterDiaBanSelect = document.getElementById("filterDiaBan");

    let options = `<option value="">Tất cả địa bàn</option>`;
    if (selectedAp) {
        let matchedDiaban = allDiaBanData.filter(x => x.ap === selectedAp);
        let uniqueDiabans = [...new Set(matchedDiaban.map(x => x.diabanh))].filter(Boolean);
        
        uniqueDiabans.forEach(db => {
            options += `<option value="${db}">${db}</option>`;
        });
    } else {
        let allDiabans = [...new Set(allDiaBanData.map(x => x.diabanh))].filter(Boolean);
        allDiabans.forEach(db => {
            options += `<option value="${db}">${db}</option>`;
        });
    }
    filterDiaBanSelect.innerHTML = options;
    loadReportData();
}

async function loadReportData() {
    const month = document.getElementById("filterMonth").value;
    const year = document.getElementById("filterYear").value;
    const selectedAp = document.getElementById("filterAp").value;
    const selectedDiaBan = document.getElementById("filterDiaBan").value;

    document.getElementById("txtMonth").innerText = month;
    document.getElementById("txtYear").innerText = year;
    
    document.getElementById("txtAp").innerText = selectedAp || (currentUserGlobal.ap || "Toàn xã");
    document.getElementById("txtDiaBan").innerText = selectedDiaBan || (currentUserGlobal.diabanh || "Toàn xã");

    // 🕒 Lấy ngày tháng năm hiện tại của hệ thống
    const today = new Date();
    const signDayEl = document.getElementById("signDay");
    const signMonthEl = document.getElementById("signMonth");
    const signYearEl = document.getElementById("signYear");

    if (signDayEl) signDayEl.innerText = today.getDate();
    if (signMonthEl) signMonthEl.innerText = today.getMonth() + 1;
    if (signYearEl) signYearEl.innerText = today.getFullYear();

    for (let i = 1; i <= 11; i++) {
        fetchAndRenderTable(i, month, year, selectedAp, selectedDiaBan);
    }
}
async function fetchAndRenderTable(tableIndex, month, year, filterAp, filterDiaBan) {
    const tbody = document.getElementById(`tbl${tableIndex}_body`);
    if (!tbody) return;

    try {
        const res = await fetch(`/api/data/table_${tableIndex}`);
        const data = await res.json();
        
        if (!Array.isArray(data)) {
            tbody.innerHTML = `<tr><td colspan="10" class="text-danger">Lỗi dữ liệu trả về từ server</td></tr>`;
            return;
        }

        let filtered = data.filter(item => {
            if (filterAp && item.ap && item.ap.trim() !== filterAp.trim()) {
                return false;
            }
            if (filterDiaBan && item.diabanh && item.diabanh.trim() !== filterDiaBan.trim()) {
                return false;
            }

            let dateVal = item.created_at || item.ngay_sinh_con || item.ngay_sinh || item.ngay_nhap || item.ngay_chet || item.ngay_den || item.ngay_di || item.ngay_su_dung || item.ngay_thoi_su_dung || item.ngay_su_kien || item.ngay_kham || "";
            if (dateVal) {
                let matchYear = dateVal.includes(year);
                let matchMonth = false;
                
                let parts = dateVal.includes("-") ? dateVal.split("-") : dateVal.split("/");
                if (parts.length >= 2) {
                    let mPart = parts[1];
                    if (parseInt(mPart) === parseInt(month)) matchMonth = true;
                } else if (dateVal.includes(`/${month}/`) || dateVal.includes(`-${month}-`)) {
                    matchMonth = true;
                }

                if (matchYear && matchMonth) return true;
                return false;
            }
            return true;
        });

       if (filtered.length === 0) {
            if (tableIndex === 9) {
                tbody.innerHTML = `
                    <tr>
                        <td></td><td></td><td></td><td>..../..../........</td><td>..../..../........</td><td></td><td></td>
                        <td rowspan="2" class="text-left align-middle" style="font-size: 9pt;">
                            <div>Số phụ nữ mang thai đến cuối tháng (T):....</div>
                            <div style="margin-top: 6px;">Số phụ nữ phá thai/sảy thai trong tháng (N):</div>
                        </td>
                    </tr>
                    <tr>
                        <td></td><td></td><td></td><td>..../..../........</td><td>..../..../........</td><td></td><td></td>
                    </tr>
                `;
                return;
            }

            let colCount = getColumnCount(tableIndex);
            tbody.innerHTML = `<tr><td colspan="${colCount}" class="text-muted fst-italic">Không có phát sinh trong tháng ${month}/${year} theo khu vực này</td></tr>`;
            return;
        }

        let html = "";
        filtered.forEach((row, index) => {
            html += generateRowHtml(tableIndex, row, index + 1);
        });
        tbody.innerHTML = html;

    } catch (err) {
        console.error(`Lỗi tải dữ liệu bảng table_${tableIndex}:`, err);
    }
}

function getColumnCount(idx) {
    const counts = {1: 10, 2: 9, 3: 8, 4: 11, 5: 9, 6: 8, 7: 6, 8: 6, 9: 8, 10: 12, 11: 7};
    return counts[idx] || 5;
}

function generateRowHtml(idx, r, stt) {
    switch(idx) {
        case 1:
            let isNam = r.gioi_tinh === 'Nam';
            let ngaySinhConFormatted = formatDateVN(r.ngay_sinh_con);
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten_con || ''}</td>
                <td>${isNam ? ngaySinhConFormatted : ''}</td>
                <td>${!isNam ? ngaySinhConFormatted : ''}</td>
                <td>${r.dan_toc || 'Kinh'}</td>
                <td class="text-left">${r.ho_ten_me || ''}</td>
                <td>${r.so_the_bhyt_me || ''}</td>
                <td>${formatDateVN(r.ngay_sinh_me)}</td>
                <td class="text-left">${r.noi_de || ''}</td>
                <td>${r.con_thu_may || '1'}</td>
            </tr>`;
        case 2:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten_tre || r.ho_ten_con || ''}</td>
                <td>${r.ma_the_bhyt_me || r.so_the_bhyt || ''}</td>
                <td>${r.suy_giap || r.benh_suy_giap || ''}</td>
                <td>${r.g6pd || r.thieu_men_g6pd || ''}</td>
                <td>${r.thuong_than || r.tang_san_thuong_than || ''}</td>
                <td>${r.khiem_thinh || ''}</td>
                <td>${r.tim_bam_sinh || r.benh_tim || ''}</td>
                <td class="text-left">${r.noi_thuc_hien || r.ghi_chu || ''}</td>
            </tr>`;
        case 3:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${r.quan_he || ''}</td>
                <td>${r.gioi_tinh || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td>${formatDateVN(r.ngay_chet)}</td>
                <td class="text-left">${r.ghi_chu || ''}</td>
            </tr>`;
        case 4:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${r.quan_he || ''}</td>
                <td>${r.gioi_tinh || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td>${r.dan_toc || ''}</td>
                <td>${r.trinh_do_hoc_van || ''}</td>
                <td>${r.tinh_trang_hon_nhan || ''}</td>
                <td>${formatDateVN(r.ngay_den)}</td>
                <td class="text-left">${r.noi_di || ''}</td>
            </tr>`;
        case 5:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${r.quan_he || ''}</td>
                <td>${r.gioi_tinh || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td>${formatDateVN(r.ngay_di)}</td>
                <td class="text-left">${r.noi_den || ''}</td>
                <td class="text-left">${r.ghi_chu || ''}</td>
            </tr>`;
        case 6:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${r.gioi_tinh || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td class="text-left">${r.thong_tin_cu || ''}</td>
                <td class="text-left">${r.thong_tin_moi || ''}</td>
                <td class="text-left">${r.ghi_chu || ''}</td>
            </tr>`;
        case 7:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten_vo || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td>${formatDateVN(r.ngay_su_dung)}</td>
                <td>${r.bptt_moi || ''}</td>
            </tr>`;
        case 8:
            return `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten_vo || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td>${formatDateVN(r.ngay_thoi_su_dung)}</td>
                <td>${r.bptt_thoi || ''}</td>
            </tr>`;
        case 9:
            let rightSummaryContent = "";
            let totalRows = filtered.length;
            
            if (stt === 1) {
                rightSummaryContent = `
                    <td rowspan="${totalRows}" class="text-left align-middle" style="font-size: 9pt; background-color: #fff;">
                        <div>Số phụ nữ mang thai đến cuối tháng (T): <span id="sumMangThai" class="fw-bold">0</span></div>
                        <div style="margin-top: 6px;">Số phụ nữ phá thai/sảy thai trong tháng (N): <span id="sumSayPhaThai" class="fw-bold">0</span></div>
                    </td>
                `;
            }

            let htmlRow = `<tr>
                <td>${formatSoHoBaoCao(r, stt)}</td>
                <td class="text-left">${r.ho_ten || ''}</td>
                <td>${r.so_the_bhyt || ''}</td>
                <td>${formatDateVN(r.ngay_sinh)}</td>
                <td>${formatDateVN(r.ngay_su_kien)}</td>
                <td>${r.su_kien || ''}</td>
                <td>${r.mang_thai_lan_thu || ''}</td>`;
            
            if (stt === 1) {
                htmlRow += rightSummaryContent;
            }
            
            htmlRow += `</tr>`;
            return htmlRow;
        case 10:
            // Tách riêng ngày thực hiện cho mốc 12 tuần và 21 tuần từ database
            let ngayThucHien12 = formatDateVN(r.ngay_thuc_hien_12 || r.ngay_kham_12 || r.ngay_sieu_am_12 || r.ngay_thuc_hien_dich_vu_12 || r.ngay_thuc_hien || r.ngay_thuc_hien_dich_vu || r.mang_thai_tuan_12);
            let ngayThucHien21 = formatDateVN(r.ngay_thuc_hien_21 || r.ngay_kham_21 || r.ngay_sieu_am_21 || r.ngay_thuc_hien_dich_vu_21 || r.mang_thai_tuan_21);
            let noiThucHien = r.noi_thuc_hien || r.ghi_chu || '';
            
            // Dòng 1: Tuần 12 (Đã bổ sung biến ${ngayThucHien12} vào ô tương ứng)
            let row1 = `<tr>
                <td rowspan="2">${formatSoHoBaoCao(r, stt)}</td>
                <td rowspan="2">${r.ma_the_bhyt || r.so_the_bhyt || ''}</td>
                <td rowspan="2" class="text-left">${r.ho_ten || ''}</td>
                <td rowspan="2" class="text-left">${r.noi_cu_tru || ''}</td>
                <td rowspan="2">${formatDateVN(r.ngay_sinh)}</td>
                <td>12 tuần</td>
                <td>${ngayThucHien12}</td>
                <td>${r.ket_qua_edward || r.edward || r.hoi_chung_edward || 'Bình thường'}</td>
                <td>${r.ket_qua_down || r.down || r.hoi_chung_down || 'Bình thường'}</td>
                <td>${r.ket_qua_patau || r.patau || r.hoi_chung_patau || 'Bình thường'}</td>
                <td>${r.ket_qua_thalassemia || r.thalassemia || r.benh_thalassemia || 'Bình thường'}</td>
                <td rowspan="2" class="text-left">${noiThucHien}</td>
                <td rowspan="2"></td>
            </tr>`;

            // Dòng 2: Tuần 21 (Đã bổ sung cột ngày thực hiện ${ngayThucHien21})
            let row2 = `<tr>
                <td>21 tuần</td>
                <td>${ngayThucHien21}</td>
                <td>${r.ket_qua_edward_21 || r.edward_21 || 'Bình thường'}</td>
                <td>${r.ket_qua_down_21 || r.down_21 || 'Bình thường'}</td>
                <td>${r.ket_qua_patau_21 || r.patau_21 || 'Bình thường'}</td>
                <td>${r.ket_qua_thalassemia_21 || r.thalassemia_21 || 'Bình thường'}</td>
            </tr>`;

            return row1 + row2;
       case 11:
        return `<tr>
            <td>${formatSoHoBaoCao(r, stt)}</td>
            <td>${r.ma_so_doi_tuong || ''}</td>
            <td class="text-left">${r.ho_ten || ''}</td>
            <td>${r.so_the_bhyt || ''}</td>
            <td>${r.nam_sinh || ''}</td>
            <td>${formatDateVN(r.ngay_kham)}</td>
            <td class="text-left">${r.ghi_chu || ''}</td>
        </tr>`;
        default:
            return `<tr><td>${stt}</td><td colspan="5">Dữ liệu bảng ${idx}</td></tr>`;
    }
}
// Hàm xuất nội dung báo cáo ra file Word (đã xử lý tách hẳn khoảng cách giữa Bảng 6 và cụm Bảng 7-8)
function exportToWord() {
    const reporterName = document.getElementById("lblReporterName").innerText || "........................................";
    const month = document.getElementById("filterMonth").value;
    const year = document.getElementById("filterYear").value;
    const diaBan = document.getElementById("txtDiaBan").innerText || "Toàn xã";
    const ap = document.getElementById("txtAp").innerText || "Toàn xã";
    const xa = document.getElementById("txtXa").innerText || "";
    const tinh = document.getElementById("txtTinh")?.innerText || "";
    const noiNhanBaoCao = currentCommuneSettings.ten_tram_y_te || document.getElementById("txtNoiNhanBaoCao")?.innerText || "";
    const adminSignName = document.getElementById("signAdminName").innerText || "..............................................";
    const ctvSignName = document.getElementById("signCtvName").innerText || reporterName;

    const reportPageEl = document.querySelector('.report-page').cloneNode(true);
    
    // Thiết lập chung cho các bảng: cỡ chữ 13pt, padding sát 2px 4px
    const tables = reportPageEl.querySelectorAll('table');
    tables.forEach((tbl) => {
        tbl.setAttribute("border", "1");
        tbl.setAttribute("cellpadding", "2");
        tbl.setAttribute("cellspacing", "0");
        tbl.style.cssText = "border-collapse: collapse; width: 100%; font-size: 13pt; font-family: 'Times New Roman', Times, serif; margin-bottom: 10px;";
    });

 // 1. Chuẩn hóa Bảng 9 cho Word (Xử lý triệt để không bị lặp dòng)
    const allTablesInCopy = reportPageEl.querySelectorAll('table');
    allTablesInCopy.forEach((tbl) => {
        let prevText = tbl.previousElementSibling ? tbl.previousElementSibling.innerText : "";
        if (prevText.includes("9.") || tbl.innerHTML.includes("sự kiện thai sản")) {
            
            let thead = tbl.querySelector('thead');
            if (!thead) {
                thead = document.createElement('thead');
                let firstRow = tbl.querySelector('tr');
                if (firstRow) thead.appendChild(firstRow);
                tbl.insertBefore(thead, tbl.firstChild);
            }

            let headerTr = thead.querySelector('tr');
            if (headerTr) {
                headerTr.innerHTML = `
                    <th style="width: 40px; text-align: center; vertical-align: middle;">Hộ số</th>
                    <th style="text-align: center; vertical-align: middle;">Họ và tên phụ nữ</th>
                    <th style="width: 80px; text-align: center; vertical-align: middle;">Số thẻ BHYT</th>
                    <th style="width: 80px; text-align: center; vertical-align: middle;">Ngày sinh</th>
                    <th style="width: 80px; text-align: center; vertical-align: middle;">Ngày có sự kiện</th>
                    <th style="width: 85px; text-align: center; vertical-align: middle;">Sự kiện thai sản</th>
                    <th style="width: 70px; text-align: center; vertical-align: middle;">Mang thai lần thứ</th>
                    <th style="width: 220px; text-align: center; vertical-align: middle;">Cộng số người có sự kiện thai sản</th>
                `;
            }

            let tbody9 = tbl.querySelector('tbody');
            if (!tbody9) {
                tbody9 = document.createElement('tbody');
                tbl.appendChild(tbody9);
            }

            // Kiểm tra xem thực tế có dữ liệu hay không (dựa vào nội dung văn bản bên trong)
            let textContent = tbody9.innerText.trim();
            let hasRealData = textContent !== "" && 
                              !textContent.includes("..../..../........") && 
                              !textContent.includes("Không có phát sinh") && 
                              !textContent.includes("Không có dữ liệu");

            if (!hasRealData) {
                // Ép cứng luôn luôn chỉ tạo đúng 2 dòng trống mẫu, không bị nhân đôi
                tbody9.innerHTML = `
                    <tr>
                        <td style="width: 40px;"></td>
                        <td></td>
                        <td style="width: 80px;"></td>
                        <td style="width: 80px; text-align:center;">..../..../........</td>
                        <td style="width: 80px; text-align:center;">..../..../........</td>
                        <td style="width: 85px;"></td>
                        <td style="width: 70px;"></td>
                        <td rowspan="2" style="width: 220px; text-align: left; vertical-align: middle; font-size: 11pt; padding: 4px; background-color: #ffffff;">
                            Số phụ nữ mang thai đến cuối tháng (T): ....<br>
                            Số phụ nữ phá thai/sảy thai trong tháng (N): 
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 40px;"></td>
                        <td></td>
                        <td style="width: 80px;"></td>
                        <td style="width: 80px; text-align:center;">..../..../........</td>
                        <td style="width: 80px; text-align:center;">..../..../........</td>
                        <td style="width: 85px;"></td>
                        <td style="width: 70px;"></td>
                    </tr>
                `;
            } else {
                let rows9 = Array.from(tbody9.querySelectorAll('tr'));
                let totalR = rows9.length;
                rows9.forEach((row, idx) => {
                    while (row.cells.length > 7) {
                        row.deleteCell(row.cells.length - 1);
                    }
                    while (row.cells.length < 7) {
                        let td = document.createElement('td');
                        row.appendChild(td);
                    }
                    if (idx === 0) {
                        let tdSummary = document.createElement('td');
                        tdSummary.setAttribute("rowspan", totalR);
                        tdSummary.style.cssText = "width: 220px; text-align: left; vertical-align: middle; font-size: 11pt; padding: 4px; background-color: #ffffff;";
                        tdSummary.innerHTML = `
                            Số phụ nữ mang thai đến cuối tháng (T): <b>0</b><br>
                            Số phụ nữ phá thai/sảy thai trong tháng (N): <b>0</b>
                        `;
                        row.appendChild(tdSummary);
                    }
                });
            }
        }
    });
    // 2. Lấy dữ liệu nội dung của bảng 7 và 8 để đưa vào cụm bảng song song
    const tbl7Html = reportPageEl.querySelector('#tbl7_body') ? reportPageEl.querySelector('#tbl7_body').innerHTML : '<tr><td colspan="6" style="text-align:center; font-style:italic;">Trống</td></tr>';
    const tbl8Html = reportPageEl.querySelector('#tbl8_body') ? reportPageEl.querySelector('#tbl8_body').innerHTML : '<tr><td colspan="6" style="text-align:center; font-style:italic;">Trống</td></tr>';

    const customTbl7_8Html = `
        <table style="width: 100%; border: none !important; margin-top: 35px; margin-bottom: 10px; font-family: 'Times New Roman', Times, serif; font-size: 13pt;">
            <tr style="border: none !important;">
                <td style="width: 49.5%; vertical-align: top; border: none !important; padding: 0;">
                    <div style="font-weight: bold; font-size: 13pt; margin-bottom: 5px;">7. Danh sách cặp vợ chồng mới sử dụng BPTT</div>
                    <table border="1" cellpadding="2" cellspacing="0" style="border-collapse: collapse; width: 100%; font-size: 13pt;">
                        <tr style="background-color: #f2f2f2; font-weight: bold; text-align: center;">
                            <td style="width: 35px;">Hộ số</td>
                            <td>Họ và tên người vợ<br>(từ 15-49 tuổi)</td>
                            <td style="width: 75px;">Số thẻ BHYT</td>
                            <td style="width: 70px;">Ngày sinh</td>
                            <td style="width: 70px;">Ngày sử dụng</td>
                            <td style="width: 65px;">BPTT mới</td>
                        </tr>
                        ${tbl7Html}
                    </table>
                </td>
                <td style="width: 1%; border: none !important; padding: 0;"></td>
                <td style="width: 49.5%; vertical-align: top; border: none !important; padding: 0;">
                    <div style="font-weight: bold; font-size: 13pt; margin-bottom: 5px;">8. Danh sách vợ chồng thôi sử dụng BPTT</div>
                    <table border="1" cellpadding="2" cellspacing="0" style="border-collapse: collapse; width: 100%; font-size: 13pt;">
                        <tr style="background-color: #f2f2f2; font-weight: bold; text-align: center;">
                            <td style="width: 35px;">Hộ số</td>
                            <td>Họ và tên người vợ<br>(từ 15-49 tuổi)</td>
                            <td style="width: 75px;">Số thẻ BHYT</td>
                            <td style="width: 70px;">Ngày sinh</td>
                            <td style="width: 70px;">Ngày thôi sử dụng</td>
                            <td style="width: 65px;">BPTT thôi sử dụng</td>
                        </tr>
                        ${tbl8Html}
                    </table>
                </td>
            </tr>
        </table>
    `;

    // Xóa bảng 7-8 cũ trong bản sao mẫu
    const oldTbl7 = reportPageEl.querySelector('#tbl7_body');
    if (oldTbl7) {
        let parentBox = oldTbl7.closest('.row') || oldTbl7.parentNode.parentNode.parentNode;
        if (parentBox && parentBox !== reportPageEl) parentBox.remove();
    }
    const oldTbl8 = reportPageEl.querySelector('#tbl8_body');
    if (oldTbl8) {
        let parentBox8 = oldTbl8.closest('.row') || oldTbl8.parentNode.parentNode.parentNode;
        if (parentBox8 && parentBox8 !== reportPageEl) parentBox8.remove();
    }

    // 3. Tìm vị trí bảng số 6 để chèn cụm bảng 7-8 ngay phía dưới đúng vị trí
    const allTablesInPage = reportPageEl.querySelectorAll('table');
    let targetElement = null;
    allTablesInPage.forEach(tbl => {
        let prevText = tbl.previousElementSibling ? tbl.previousElementSibling.innerText : "";
        if (prevText.includes("6.") || tbl.innerHTML.includes("thông tin cơ bản")) {
            targetElement = tbl.closest('.row') || tbl.parentNode;
        }
    });

    if (targetElement && targetElement !== reportPageEl) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = customTbl7_8Html;
        targetElement.parentNode.insertBefore(tempDiv.firstElementChild, targetElement.nextSibling);
    } else {
        reportPageEl.innerHTML += customTbl7_8Html;
    }

    // 4. Tạo Header dạng bảng ẩn không viền cho file Word
    const headerTableHtml = `
        <table style="width: 100%; border: none !important; margin-bottom: 10px; font-family: 'Times New Roman', Times, serif; font-size: 13pt;">
            <tr style="border: none !important;">
                <td style="width: 55%; text-align: left; vertical-align: top; border: none !important; padding: 0;">
                    <p style="margin: 0; font-weight: bold;">Phiếu P0/CTV (tờ 1)</p>
                    <p style="margin: 0; font-style: italic; font-size: 12pt;">(Ban hành kèm theo Thông tư số 01/2022/TT-BYT)</p>
                    <p style="margin: 0; font-size: 12pt;">Thời điểm lập: Ngày 01 của tháng sau tháng báo cáo</p>
                </td>
                <td style="width: 45%; text-align: right; vertical-align: top; border: none !important; padding: 0; font-size: 12pt;">
                    <p style="margin: 0;">Người báo cáo: ${reporterName}</p>
                    <p style="margin: 0;">Nơi nhận báo cáo: ${noiNhanBaoCao}</p>
                </td>
            </tr>
        </table>
        <div style="text-align: center; margin: 10px 0;">
            <h3 style="margin: 0; font-weight: bold; font-size: 15pt; text-transform: uppercase;">PHIẾU THU TIN VỀ DÂN SỐ THÁNG ${month} NĂM ${year}</h3>
            <p style="margin: 3px 0 0 0; font-size: 13pt;">
                Địa bàn: ${diaBan} &nbsp;&nbsp;&nbsp; 
                Thôn: ${ap} &nbsp;&nbsp;&nbsp; 
                Xã: ${xa} &nbsp;&nbsp;&nbsp; Tỉnh: ${tinh}
            </p>
        </div>
    `;

    // 5. Tạo Footer (Phần chữ ký cuối trang)
    const today = new Date();
    const curDay = today.getDate();
    const curMonth = today.getMonth() + 1;
    const curYear = today.getFullYear();

    const footerTableHtml = `
        <table style="width: 100%; border: none !important; margin-top: 25px; font-family: 'Times New Roman', Times, serif; font-size: 13pt;">
            <tr style="border: none !important;">
                <td style="width: 50%; text-align: center; vertical-align: top; border: none !important; padding: 0;">
                    <p style="margin: 0; font-weight: bold;">Cán bộ dân số xã thẩm định</p>
                    <p style="margin: 0; font-style: italic; font-size: 12pt;">(Ký, ghi rõ họ và tên)</p>
                    <div style="height: 50px;"></div>
                    <p style="margin: 0; font-weight: bold;">${adminSignName}</p>
                </td>
                <td style="width: 50%; text-align: center; vertical-align: top; border: none !important; padding: 0;">
                    <p style="margin: 0; font-size: 12pt; font-style: italic;">${xa}, ngày ${curDay} tháng ${curMonth} năm ${curYear}</p>
                    <p style="margin: 2px 0 0 0; font-weight: bold;">Cộng tác viên dân số lập phiếu</p>
                    <p style="margin: 0; font-style: italic; font-size: 12pt;">(Ký, ghi rõ họ và tên)</p>
                    <div style="height: 50px;"></div>
                    <p style="margin: 0; font-weight: bold;">${ctvSignName}</p>
                </td>
            </tr>
        </table>
    `;

    const oldHeaderDiv = reportPageEl.querySelector('.row.mb-3');
    const oldTitleDiv = reportPageEl.querySelector('.text-center.my-3');
    const oldFooterDiv = reportPageEl.querySelector('.row.mt-5');
    
    if (oldHeaderDiv) oldHeaderDiv.remove();
    if (oldTitleDiv) oldTitleDiv.remove();
    if (oldFooterDiv) oldFooterDiv.remove();

    const finalBodyContent = headerTableHtml + reportPageEl.innerHTML + footerTableHtml;

    const htmlHeader = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' 
              xmlns:w='urn:schemas-microsoft-com:office:word' 
              xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
            <meta charset='utf-8'>
            <title>Phiếu P0/CTV</title>
            <xml>
                <w:WordDocument>
                    <w:View>Print</w:View>
                    <w:DoNotOptimizeForBrowser/>
                </w:WordDocument>
            </xml>
            <style>
                @page Section1 {
                    size: 29.7cm 21cm;
                    mso-page-orientation: landscape;
                    margin: 1.2cm;
                }
                div.Section1 { page: Section1; }
                body { font-family: 'Times New Roman', Times, serif; font-size: 13pt; }
                table { border-collapse: collapse; width: 100%; margin-top: 3px; margin-bottom: 10px; mso-table-lspace:0pt; mso-table-rspace:0pt; }
                th, td { border: 1px solid black; padding: 2px 4px; text-align: center; vertical-align: middle; font-size: 13pt; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .text-left { text-align: left; }
                p { margin-bottom: 4px; }
            </style>
        </head>
        <body>
            <div class="Section1">
    `;
    const htmlFooter = "</div></body></html>";
    const completeHtml = htmlHeader + finalBodyContent + htmlFooter;

    const blob = new Blob(['\ufeff' + completeHtml], {
        type: 'application/msword'
    });
    
    const filename = `Phieu_P0_CTV_Thang_${month}_Nam_${year}.doc`;
    const downloadLink = document.createElement("a");
    downloadLink.href = URL.createObjectURL(blob);
    downloadLink.download = filename;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}